#include <stdio.h>

struct Employee
{
    int id;
    char name[30];
    float salary;
};

int main()
{
    struct Employee e[3];
    int i;

    for (i = 0; i < 3; i++)
    {
        printf("Enter ID, Name, Salary: ");
        scanf("%d %s %f", &e[i].id, e[i].name, &e[i].salary);

        if (e[i].salary < 50000)
        {
            e[i].salary = e[i].salary + e[i].salary * 0.10;
        }
    }

    printf("\n--- Updated Salaries ---\n");

    for (i = 0; i < 3; i++)
    {
        printf("%d %s %.2f\n",
               e[i].id, e[i].name, e[i].salary);
    }

    return 0;
}

