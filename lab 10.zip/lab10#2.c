#include <stdio.h>

void reverseDigits(int num)
{
    if (num == 0)
    {
        return;
    }

    printf("%d", num % 10);

    reverseDigits(num / 10);
}

int main()
{
    int num;

    printf("Enter number: ");
    scanf("%d", &num);

    printf("Reversed: ");

    if (num == 0)
    {
        printf("0");
    }
    else
    {
        reverseDigits(num);
    }

    return 0;
}

