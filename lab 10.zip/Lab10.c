#include <stdio.h>

int totalCalories(int n)
{
    if (n == 0)
    {
        return 0;
    }

    return (n * 5) + totalCalories(n - 1);
}

int main()
{
    int n;

    printf("Enter number of steps: ");
    scanf("%d", &n);

    printf("Total calories burned: %d", totalCalories(n));

    return 0;
}

